export class Size{
    constructor(
        public taille: string,
        public price: number
    ){

    }
}